:- consult('logic.pl').
:- consult('menu.pl').
:- consult('display.pl').
:- consult('utilities.pl').
:- consult('input.pl').
:- consult('bot.pl').
:- use_module(library(random)).
:- use_module(library(system)).

iris :-
      play.